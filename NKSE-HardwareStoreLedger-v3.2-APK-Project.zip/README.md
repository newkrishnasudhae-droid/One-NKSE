# NKSE Hardware Store Ledger — Android Project v3.2

Corrected Android WebView source project for New Krishna Sudha Enterprise (NKSE).

## Included
- Navy-blue NKSE square app icon and in-app branding.
- Customer management.
- One transaction with multiple items: item name, quantity, unit, price/unit, line total and grand total.
- Paid amount and automatic due.
- Day-by-day customer history with all items, paid, transaction due and running due.
- Customer statement Print / Save as PDF.
- Store report Print / Save as PDF.
- CSV customer statement export.
- Choose files: images, audio/voice, video, PDF, Word, Excel, TXT, CSV, ZIP and other documents.
- Multiple attachments per transaction.
- Attachment preview for image/audio/video and Android Save/Download dialog.
- Voice recording with microphone permission.
- JSON backup and Restore Backup, including saved attachment data.

## Build APK
Open this folder in Android Studio, then use:
Build > Build App Bundle(s) / APK(s) > Build APK(s)

The debug APK will normally be under:
app/build/outputs/apk/debug/app-debug.apk

This ZIP contains the Android source project. A compiled APK binary is not included because this environment does not have a configured Android Gradle build toolchain.

# New Krishna Sudha Enterprise — Hardware Store Ledger

## Branding
- The supplied NKSE navy-blue square logo is used as the **Android app launcher icon (outside the app)**.
- The logo is **not shown inside the app**.
- After opening the app, the web screen has a simple heading: **New Krishna Sudha Enterprise**.

## Included features
- Multi-item transactions: item, quantity, unit, price and automatic totals
- Paid and due tracking
- Customer day-by-day history and statements
- Customer statement Print / Save as PDF
- Attach images, audio/voice, video and documents; preview and save/download
- JSON backup and restore
- Print / PDF reports

## Build
Open this project in Android Studio and build the APK from the Gradle project.

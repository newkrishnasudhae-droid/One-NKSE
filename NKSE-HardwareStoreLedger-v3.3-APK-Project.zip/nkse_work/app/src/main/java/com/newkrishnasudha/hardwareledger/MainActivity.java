package com.newkrishnasudha.hardwareledger;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.provider.Settings;
import android.util.Base64;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.nio.charset.StandardCharsets;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MainActivity extends Activity {
    private static final int FILE_CHOOSER = 101;
    private static final int RESTORE_PICKER = 102;
    private static final int CREATE_BACKUP = 103;
    private static final int AUDIO_PERMISSION = 104;
    private static final int CREATE_DOWNLOAD = 105;

    private WebView webView;
    private ValueCallback<Uri[]> filePathCallback;
    private PermissionRequest pendingPermissionRequest;
    private String pendingBackupJson;
    private String pendingDownloadName;
    private String pendingDownloadMime;
    private byte[] pendingDownloadBytes;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setJavaScriptCanOpenWindowsAutomatically(true);

        webView.addJavascriptInterface(new AndroidBridge(), "Android");
        webView.setWebViewClient(new WebViewClient() {
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) { return false; }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                    startActivityForResult(intent, FILE_CHOOSER);
                } catch (Exception e) {
                    try {
                        Intent fallback = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        fallback.addCategory(Intent.CATEGORY_OPENABLE);
                        fallback.setType("*/*");
                        fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
                        startActivityForResult(fallback, FILE_CHOOSER);
                    } catch (Exception ignored) {
                        filePathCallback = null;
                        callback.onReceiveValue(null);
                        Toast.makeText(MainActivity.this, "ফাইল নির্বাচন করা যাচ্ছে না", Toast.LENGTH_SHORT).show();
                    }
                }
                return true;
            }

            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> {
                    if (hasAudioPermission()) {
                        request.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
                    } else {
                        pendingPermissionRequest = request;
                        requestAudioPermission();
                    }
                });
            }
        });

        webView.loadUrl("file:///android_asset/index.html");
    }

    private boolean hasAudioPermission() {
        return android.os.Build.VERSION.SDK_INT < 23 ||
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED;
    }

    private void requestAudioPermission() {
        if (android.os.Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, AUDIO_PERMISSION);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == AUDIO_PERMISSION && pendingPermissionRequest != null) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                pendingPermissionRequest.grant(new String[]{PermissionRequest.RESOURCE_AUDIO_CAPTURE});
            } else {
                pendingPermissionRequest.deny();
                Toast.makeText(this, "ভয়েস রেকর্ডের জন্য Microphone permission প্রয়োজন", Toast.LENGTH_LONG).show();
            }
            pendingPermissionRequest = null;
        }
    }

    private void openRestorePicker() {
        Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"application/json", "text/json", "text/plain", "*/*"});
        startActivityForResult(i, RESTORE_PICKER);
    }

    private void createBackup(String json, String filename) {
        pendingBackupJson = json;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("application/json");
        i.putExtra(Intent.EXTRA_TITLE, filename);
        startActivityForResult(i, CREATE_BACKUP);
    }

    private void saveDataUrl(String name, String dataUrl) {
        try {
            if (dataUrl == null || !dataUrl.startsWith("data:")) {
                Toast.makeText(this, "ফাইল ডেটা পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
                return;
            }
            Matcher m = Pattern.compile("^data:([^;,]+)").matcher(dataUrl);
            String mime = m.find() ? m.group(1) : "application/octet-stream";
            int comma = dataUrl.indexOf(',');
            if (comma < 0) throw new Exception("invalid data url");
            String encoded = dataUrl.substring(comma + 1);
            pendingDownloadBytes = Base64.decode(encoded, Base64.DEFAULT);
            pendingDownloadName = (name == null || name.trim().isEmpty()) ? "download" : name;
            pendingDownloadMime = mime;

            Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(mime);
            i.putExtra(Intent.EXTRA_TITLE, pendingDownloadName);
            startActivityForResult(i, CREATE_DOWNLOAD);
        } catch (Exception e) {
            Toast.makeText(this, "ফাইল Download করার জন্য প্রস্তুত করা যায়নি", Toast.LENGTH_LONG).show();
            clearPendingDownload();
        }
    }

    private void clearPendingDownload() {
        pendingDownloadBytes = null;
        pendingDownloadName = null;
        pendingDownloadMime = null;
    }

    private String readUri(Uri uri) throws Exception {
        StringBuilder out = new StringBuilder();
        try (InputStream in = getContentResolver().openInputStream(uri);
             BufferedReader br = new BufferedReader(new InputStreamReader(in, StandardCharsets.UTF_8))) {
            String line;
            while ((line = br.readLine()) != null) out.append(line).append('\n');
        }
        return out.toString();
    }

    private void restoreJson(String json) {
        try {
            JSONObject obj = new JSONObject(json);
            String safe = JSONObject.quote(obj.toString());
            webView.evaluateJavascript("window.restoreFromNative && window.restoreFromNative(" + safe + ");", null);
        } catch (Exception e) {
            Toast.makeText(this, "ভুল JSON backup file", Toast.LENGTH_LONG).show();
        }
    }

    private void printPage() {
        PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (printManager == null) {
            Toast.makeText(this, "Print service পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
            return;
        }
        String jobName = "Hardware Store Ledger";
        android.print.PrintDocumentAdapter adapter = webView.createPrintDocumentAdapter(jobName);
        printManager.print(jobName, adapter, new PrintAttributes.Builder()
                .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                .setResolution(new PrintAttributes.Resolution("ledger", "Ledger", 300, 300))
                .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                .build());
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER) {
            if (filePathCallback == null) return;
            Uri[] results = null;
            if (resultCode == Activity.RESULT_OK && data != null) {
                results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
                if (results == null && data.getData() != null) results = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == RESTORE_PICKER) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null) {
                try {
                    getContentResolver().takePersistableUriPermission(data.getData(), Intent.FLAG_GRANT_READ_URI_PERMISSION);
                } catch (Exception ignored) {}
                try {
                    restoreJson(readUri(data.getData()));
                } catch (Exception e) {
                    Toast.makeText(this, "Backup পড়া যায়নি", Toast.LENGTH_LONG).show();
                }
            }
        } else if (requestCode == CREATE_BACKUP) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null && pendingBackupJson != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    out.write(pendingBackupJson.getBytes(StandardCharsets.UTF_8));
                    Toast.makeText(this, "JSON Backup সংরক্ষণ হয়েছে", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "Backup সংরক্ষণ করা যায়নি", Toast.LENGTH_LONG).show();
                }
            }
            pendingBackupJson = null;
        } else if (requestCode == CREATE_DOWNLOAD) {
            if (resultCode == Activity.RESULT_OK && data != null && data.getData() != null && pendingDownloadBytes != null) {
                try (OutputStream out = getContentResolver().openOutputStream(data.getData())) {
                    out.write(pendingDownloadBytes);
                    Toast.makeText(this, "ফাইল Download/সংরক্ষণ হয়েছে", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Toast.makeText(this, "ফাইল সংরক্ষণ করা যায়নি", Toast.LENGTH_LONG).show();
                }
            }
            clearPendingDownload();
        }
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class AndroidBridge {
        @JavascriptInterface public void openRestorePicker() { runOnUiThread(MainActivity.this::openRestorePicker); }
        @JavascriptInterface public void printPage() { runOnUiThread(MainActivity.this::printPage); }
        @JavascriptInterface public void saveBackup(String json, String filename) { runOnUiThread(() -> createBackup(json, filename)); }
        @JavascriptInterface public void downloadDataUrl(String name, String dataUrl) { runOnUiThread(() -> saveDataUrl(name, dataUrl)); }
        @JavascriptInterface public void openAppSettings() {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + getPackageName()));
            startActivity(i);
        }
    }
}

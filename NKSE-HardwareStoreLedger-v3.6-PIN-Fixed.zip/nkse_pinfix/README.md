# NKSE Hardware Store Ledger v3.4

Android WebView project for New Krishna Sudha Enterprise.

## Security PIN
- First launch: create a 4–6 digit Security PIN.
- Every subsequent app launch shows the PIN login screen.
- PIN is stored as a SHA-256 hash in localStorage, not as plain text.
- Change PIN anytime from the **Security PIN → PIN পরিবর্তন করুন** section.
- New PIN requires current PIN verification and confirmation.

## Branding
- App icon: NKSE navy-blue square logo.
- Inside app: simple heading **New Krishna Sudha Enterprise**, no logo.

## Build
Open the project in Android Studio and build the debug APK.


### v3.5 USB / Pendrive Export
- One-tap “সব হিসাব Pendrive / USB” exports the latest complete customer/transaction backup to a ZIP through Android Storage Access Framework.
- ZIP contains backup.json, customers.csv, transactions.csv, README.txt and saved attachments (photos, audio, video and documents).
- In the Android picker, choose the USB OTG/Pendrive folder or storage location and save the ZIP.
- Android security requires the user to choose the destination; the app cannot silently write to a USB drive.

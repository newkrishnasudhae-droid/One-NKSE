# Hardware Store Ledger — Corrected Multi-Item Version

Android offline hardware-store customer ledger.

## New transaction features
- One customer can take **many different items in one transaction**.
- Tap **＋ মাল যোগ করুন** to add unlimited item rows.
- Each item has: **মালের নাম, পরিমাণ, ইউনিট, দাম/ইউনিট, line total**.
- Grand total is calculated automatically.
- One **মোট জমা** amount can be entered for the complete transaction.
- **বর্তমান বাকি** is calculated automatically.
- Editing an old transaction loads all of its item rows.
- Older single-item transactions remain compatible.
- Search and customer account show all items in a transaction.

## Existing corrected Android features
- Android file chooser for transaction evidence.
- JSON Restore Backup picker.
- Android Print / Save as PDF.
- JSON backup save through Android document picker.
- Voice recording permission handling.

## Build
Open this project in Android Studio and build the debug APK:
`Build > Build Bundle(s) / APK(s) > Build APK(s)`

Package: `com.newkrishnasudha.hardwareledger`

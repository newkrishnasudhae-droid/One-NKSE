# Hardware Store Ledger — Corrected Android Project v2.0

এই project-এ আগের ৩টি Android/WebView সমস্যা ঠিক করা হয়েছে:

1. **Choose files** — Android WebView file chooser support (`onShowFileChooser`)। Multiple image/PDF/document নির্বাচন করা যাবে।
2. **Restore Backup** — native Android JSON file picker; নির্বাচিত backup WebView-তে restore হবে।
3. **Print / PDF** — Android `PrintManager` ব্যবহার করে system print dialog খুলবে; সেখান থেকে **Save as PDF** করা যাবে।

অতিরিক্তভাবে:
- JSON Backup এখন Android-এর **Create Document** picker দিয়ে নির্দিষ্ট জায়গায় save করা যায়।
- Voice recording-এর জন্য `RECORD_AUDIO` runtime permission ও WebView audio permission handling যোগ করা হয়েছে।
- Offline data `localStorage`-এ আগের মতো থাকে।

## Build

Android Studio-তে এই folder open করুন। Gradle sync হওয়ার পর:

**Build → Build Bundle(s) / APK(s) → Build APK(s)**

Debug APK সাধারণত `app/build/outputs/apk/debug/app-debug.apk`-এ তৈরি হবে।

## Important

এই source project build করতে Android Studio/Gradle-কে internet থেকে Android Gradle Plugin এবং AndroidX dependency নিতে হতে পারে।
